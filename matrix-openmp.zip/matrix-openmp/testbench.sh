#!/bin/bash

			./forloop $10
